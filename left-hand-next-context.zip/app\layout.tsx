import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "LEFT HAND - Onthidithoi",
  description:
    "LEFT HAND - Onthidithoi là hệ sinh thái học tập dành cho sinh viên UFM, giúp tìm đúng tài liệu, tutor và lớp ôn trước mỗi kỳ thi."
};

export default function RootLayout({
  children
}: Readonly<{
  children: ReactNode;
}>) {
  return (
    <html lang="vi" suppressHydrationWarning>
      <body className="font-body text-ink antialiased">{children}</body>
    </html>
  );
}
