import { AboutSection } from "@/components/site/about-section";
import { ConsultationForm } from "@/components/site/consultation-form";
import { EcosystemSection } from "@/components/site/ecosystem-section";
import { FeaturedResources } from "@/components/site/featured-resources";
import { Footer } from "@/components/site/footer";
import { Header } from "@/components/site/header";
import { Hero } from "@/components/site/hero";
import { ImpactStats } from "@/components/site/impact-stats";
import { ProcessSection } from "@/components/site/process-section";
import { ServicesSection } from "@/components/site/services-section";
import { TestimonialsSection } from "@/components/site/testimonials-section";

export default function HomePage() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-paper">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-grid-paper bg-[size:54px_54px] opacity-[0.08]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[28rem] bg-[radial-gradient(circle_at_top_left,rgba(31,111,255,0.18),transparent_34%),radial-gradient(circle_at_top_right,rgba(255,191,71,0.2),transparent_32%),linear-gradient(180deg,rgba(255,255,255,0.8),rgba(248,244,232,0.4))]" />
      <div className="pointer-events-none absolute inset-x-0 top-[32rem] -z-10 h-[24rem] bg-[radial-gradient(circle_at_center,rgba(30,168,139,0.14),transparent_24%),radial-gradient(circle_at_left,rgba(31,111,255,0.08),transparent_26%)]" />

      <Header />

      <main className="pb-12">
        <Hero />
        <AboutSection />
        <ImpactStats />
        <ServicesSection />
        <FeaturedResources />
        <ProcessSection />
        <ConsultationForm />
        <TestimonialsSection />
        <EcosystemSection />
      </main>

      <Footer />
    </div>
  );
}
