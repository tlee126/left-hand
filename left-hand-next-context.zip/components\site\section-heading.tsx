import { cn } from "@/lib/cn";

type SectionHeadingProps = {
  title: string;
  description?: string;
  align?: "left" | "center";
  className?: string;
};

export function SectionHeading({
  title,
  description,
  align = "center",
  className
}: SectionHeadingProps) {
  return (
    <div
      className={cn(
        "mb-7",
        align === "center" ? "section-copy" : "max-w-2xl",
        className
      )}
    >
      <h2 className="text-balance text-3xl font-bold leading-tight sm:text-4xl">
        {title}
      </h2>
      {description ? (
        <p
          className={cn(
            "mt-3 text-[15px] leading-7 text-ink/70 sm:text-base",
            align === "center" ? "mx-auto" : ""
          )}
        >
          {description}
        </p>
      ) : null}
    </div>
  );
}
