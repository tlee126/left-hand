"use client";

import { LoaderCircle } from "lucide-react";
import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { MotionReveal } from "@/components/site/motion-reveal";
import { faculties, interests, needs } from "@/data/site";

type FormValues = {
  fullName: string;
  phone: string;
  faculty: string;
  interest: string;
  need: string;
  note: string;
};

type FormErrors = Partial<Record<keyof FormValues, string>>;

const initialValues: FormValues = {
  fullName: "",
  phone: "",
  faculty: "",
  interest: "",
  need: "",
  note: ""
};

export function ConsultationForm() {
  const [values, setValues] = useState<FormValues>(initialValues);
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<"idle" | "loading" | "success">("idle");
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isLoading = status === "loading";

  const helperMessage = useMemo(() => {
    if (status === "success") {
      return "Đã nhận nhu cầu của bạn. LEFT HAND sẽ liên hệ lại với gợi ý phù hợp.";
    }

    if (Object.keys(errors).length > 0) {
      return "Vui lòng kiểm tra lại các trường bắt buộc.";
    }

    return "Điền nhanh nhu cầu hiện tại để team gợi ý tài liệu, tutor hoặc lớp ôn đúng môn.";
  }, [errors, status]);

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  function validate(nextValues: FormValues) {
    const nextErrors: FormErrors = {};

    if (!nextValues.fullName.trim()) nextErrors.fullName = "Vui lòng nhập họ và tên.";
    if (!nextValues.phone.trim()) {
      nextErrors.phone = "Vui lòng nhập số điện thoại.";
    } else if (nextValues.phone.replace(/\D/g, "").length < 9) {
      nextErrors.phone = "Số điện thoại chưa hợp lệ.";
    }
    if (!nextValues.faculty) nextErrors.faculty = "Vui lòng chọn khoa.";
    if (!nextValues.interest) nextErrors.interest = "Vui lòng chọn môn học.";
    if (!nextValues.need) nextErrors.need = "Vui lòng chọn nhu cầu.";

    return nextErrors;
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextErrors = validate(values);
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      setStatus("idle");
      return;
    }

    setStatus("loading");

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      setStatus("success");
      setValues(initialValues);
      setErrors({});
    }, 1200);
  }

  return (
    <section id="contact" className="container-shell pt-5">
      <div className="section-shell px-5 py-8 sm:px-8 sm:py-10 lg:px-10">
        <div className="grid gap-5 xl:grid-cols-[1.4fr_0.9fr]">
          <MotionReveal>
            <div className="surface-card h-full p-6 sm:p-8">
              <h2 className="text-3xl font-bold leading-tight">Đăng ký tư vấn</h2>
              <p className="mt-3 text-[15px] leading-7 text-ink/72">
                {helperMessage}
              </p>

              <form className="mt-6 grid gap-4" noValidate onSubmit={handleSubmit}>
                <div className="grid gap-4 md:grid-cols-2">
                  <Field
                    label="Họ và tên *"
                    error={errors.fullName}
                    input={
                      <input
                        value={values.fullName}
                        onChange={(event) =>
                          setValues((current) => ({
                            ...current,
                            fullName: event.target.value
                          }))
                        }
                        placeholder="Ví dụ: Nguyễn Văn A"
                        className={inputClass(Boolean(errors.fullName))}
                      />
                    }
                  />

                  <Field
                    label="Số điện thoại *"
                    error={errors.phone}
                    input={
                      <input
                        value={values.phone}
                        onChange={(event) =>
                          setValues((current) => ({
                            ...current,
                            phone: event.target.value
                          }))
                        }
                        placeholder="Ví dụ: 09xx xxx xxx"
                        inputMode="tel"
                        className={inputClass(Boolean(errors.phone))}
                      />
                    }
                  />

                  <Field
                    label="Khoa *"
                    error={errors.faculty}
                    input={
                      <select
                        value={values.faculty}
                        onChange={(event) =>
                          setValues((current) => ({
                            ...current,
                            faculty: event.target.value
                          }))
                        }
                        className={inputClass(Boolean(errors.faculty))}
                      >
                        <option value="">Chọn khoa</option>
                        {faculties.map((faculty) => (
                          <option key={faculty} value={faculty}>
                            {faculty}
                          </option>
                        ))}
                      </select>
                    }
                  />

                  <Field
                    label="Môn học / học phần quan tâm *"
                    error={errors.interest}
                    input={
                      <select
                        value={values.interest}
                        onChange={(event) =>
                          setValues((current) => ({
                            ...current,
                            interest: event.target.value
                          }))
                        }
                        className={inputClass(Boolean(errors.interest))}
                      >
                        <option value="">Chọn môn học hoặc học phần</option>
                        {interests.map((interest) => (
                          <option key={interest} value={interest}>
                            {interest}
                          </option>
                        ))}
                      </select>
                    }
                  />
                </div>

                <Field
                  label="Bạn đang cần gì? *"
                  error={errors.need}
                  input={
                    <select
                      value={values.need}
                      onChange={(event) =>
                        setValues((current) => ({
                          ...current,
                          need: event.target.value
                        }))
                      }
                      className={inputClass(Boolean(errors.need))}
                    >
                      <option value="">Chọn nhu cầu</option>
                      {needs.map((need) => (
                        <option key={need} value={need}>
                          {need}
                        </option>
                      ))}
                    </select>
                  }
                />

                <Field
                  label="Ghi chú không bắt buộc"
                  input={
                    <textarea
                      value={values.note}
                      onChange={(event) =>
                        setValues((current) => ({
                          ...current,
                          note: event.target.value
                        }))
                      }
                      placeholder="Ví dụ: Mình cần ôn giữa kỳ gấp, đang kẹt phần nào, hoặc muốn học vào buổi tối."
                      className={`${inputClass(false)} min-h-32 resize-y`}
                    />
                  }
                />

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="primary-button min-w-[170px] disabled:cursor-not-allowed disabled:opacity-70"
                  >
                    {isLoading ? (
                      <>
                        <LoaderCircle className="mr-2 h-4 w-4 animate-spin" />
                        Đang gửi...
                      </>
                    ) : (
                      "Gửi nhu cầu"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </MotionReveal>

          <MotionReveal delay={0.08}>
            <aside className="h-full rounded-[28px] border border-amber-200/70 bg-[linear-gradient(145deg,rgba(255,245,214,0.96),rgba(255,255,255,0.9))] p-6 shadow-soft sm:p-8">
              <span className="eyebrow">LEFT HAND phản hồi như thế nào?</span>
              <h3 className="mt-5 text-balance text-2xl font-semibold leading-9">
                Bạn để lại nhu cầu, LEFT HAND sẽ xem môn học và gợi ý tài liệu,
                lớp ôn hoặc tutor phù hợp.
              </h3>

              <ul className="mt-6 space-y-4 text-[15px] leading-7 text-ink/76">
                <li className="flex gap-3">
                  <span className="mt-2 h-2.5 w-2.5 shrink-0 rounded-full bg-accent" />
                  <span>Ghi chú không bắt buộc, nhưng càng rõ thì gợi ý càng sát.</span>
                </li>
                <li className="flex gap-3">
                  <span className="mt-2 h-2.5 w-2.5 shrink-0 rounded-full bg-accent" />
                  <span>Team sẽ lọc theo môn học và phần đang kẹt để đề xuất nhanh hơn.</span>
                </li>
                <li className="flex gap-3">
                  <span className="mt-2 h-2.5 w-2.5 shrink-0 rounded-full bg-accent" />
                  <span>Nếu cần gấp, cứ để lại thông tin ngắn gọn để được ưu tiên phản hồi.</span>
                </li>
              </ul>
            </aside>
          </MotionReveal>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  error,
  input
}: {
  label: string;
  error?: string;
  input: ReactNode;
}) {
  return (
    <label className="grid gap-2 text-sm font-medium text-ink/85">
      <span>{label}</span>
      {input}
      {error ? <span className="text-sm text-rose-600">{error}</span> : null}
    </label>
  );
}

function inputClass(hasError: boolean) {
  return [
    "w-full rounded-[18px] border bg-white px-4 py-3 text-sm text-ink transition focus:border-accent/50 focus:ring-4 focus:ring-accent/10",
    hasError ? "border-rose-300" : "border-slate-200"
  ].join(" ");
}
