import { MotionReveal } from "@/components/site/motion-reveal";
import { SectionHeading } from "@/components/site/section-heading";
import { featureIcons } from "@/components/site/icon-map";
import { services } from "@/data/site";

export function ServicesSection() {
  return (
    <section id="services" className="container-shell pt-5">
      <div className="section-shell px-5 py-8 sm:px-8 sm:py-10 lg:px-10">
        <MotionReveal>
          <SectionHeading
            title="Dịch vụ của LEFT HAND"
            description="Bốn trụ cột của LEFT HAND được thiết kế để sinh viên UFM có thể chọn đúng hình thức học theo từng giai đoạn ôn tập."
          />
        </MotionReveal>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {services.map((item, index) => {
            const Icon = featureIcons[item.icon];

            return (
              <MotionReveal key={item.title} delay={0.05 * index}>
                <article className="surface-card hover-lift flex h-full flex-col gap-4 p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink/[0.05] text-ink">
                    <Icon className="h-6 w-6" />
                  </div>
                  <span className="eyebrow w-fit">{item.label}</span>
                  <h3 className="text-xl font-semibold leading-8">{item.title}</h3>
                  <p className="text-[15px] leading-7 text-ink/72">{item.body}</p>
                </article>
              </MotionReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
