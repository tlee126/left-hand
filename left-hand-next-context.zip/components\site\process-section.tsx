import { MotionReveal } from "@/components/site/motion-reveal";
import { SectionHeading } from "@/components/site/section-heading";
import { featureIcons } from "@/components/site/icon-map";
import { processSteps } from "@/data/site";

export function ProcessSection() {
  return (
    <section id="process" className="container-shell pt-5">
      <div className="section-shell px-5 py-8 sm:px-8 sm:py-10 lg:px-10">
        <MotionReveal>
          <SectionHeading
            title="Quy trình đăng ký"
            description="Chỉ cần vài bước là team có thể hiểu bạn đang cần tài liệu, tutor, lớp ôn hay một hướng hỗ trợ khác."
          />
        </MotionReveal>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {processSteps.map((item, index) => {
            const Icon = featureIcons[item.icon];

            return (
              <MotionReveal key={item.step} delay={0.05 * index}>
                <article className="surface-card hover-lift flex h-full flex-col p-6">
                  <div className="mb-5 flex items-center justify-between">
                    <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-accent to-sky-400 text-sm font-semibold text-white">
                      {item.step}
                    </span>
                    <Icon className="h-5 w-5 text-accent" />
                  </div>
                  <h3 className="text-lg font-semibold leading-7">{item.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-ink/72">{item.body}</p>
                </article>
              </MotionReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
