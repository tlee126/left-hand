import Link from "next/link";
import { MotionReveal } from "@/components/site/motion-reveal";
import { SectionHeading } from "@/components/site/section-heading";
import { socialIcons } from "@/components/site/icon-map";
import { socialLinks } from "@/data/site";

export function EcosystemSection() {
  return (
    <section id="ecosystem" className="container-shell pt-5">
      <div className="section-shell px-5 py-8 sm:px-8 sm:py-10 lg:px-10">
        <MotionReveal>
          <SectionHeading
            title="Kết nối với LEFT HAND"
            description="Theo dõi các kênh để xem lịch lớp ôn, video mới và thông báo hỗ trợ khi kỳ thi đến gần."
          />
        </MotionReveal>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {socialLinks.map((item, index) => {
            const Icon = socialIcons[item.icon];

            return (
              <MotionReveal key={item.name} delay={0.05 * index}>
                <article className="surface-card hover-lift flex h-full flex-col gap-4 p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink text-xl text-white">
                    <Icon />
                  </div>
                  <h3 className="text-xl font-semibold">{item.name}</h3>
                  <p className="flex-1 text-[15px] leading-7 text-ink/72">
                    {item.description}
                  </p>
                  <Link
                    href={item.href}
                    className="inline-flex w-fit items-center text-sm font-semibold text-accent transition hover:translate-x-0.5"
                  >
                    {item.cta}
                  </Link>
                </article>
              </MotionReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
