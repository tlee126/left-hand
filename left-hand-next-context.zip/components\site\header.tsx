"use client";

import Image from "next/image";
import Link from "next/link";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { navItems } from "@/data/site";

export function Header() {
  const [open, setOpen] = useState(false);
  const shouldReduceMotion = useReducedMotion();

  return (
    <header className="sticky top-3 z-50 px-3 sm:px-4">
      <div className="container-shell mt-3 rounded-[28px] border border-white/70 bg-white/85 px-4 py-3 shadow-soft backdrop-blur-xl sm:px-6">
        <div className="flex min-h-[72px] items-center justify-between gap-4 sm:min-h-[78px] lg:min-h-[84px]">
          <Link
            href="#home"
            className="shrink-0 transition duration-300 hover:scale-[1.02]"
            aria-label="LEFT HAND - về đầu trang"
          >
            <Image
              src="/assets/branding/logo-left-hand-onthidithoi.png"
              alt="LEFT HAND - Onthidithoi"
              width={560}
              height={178}
              priority
              className="h-auto w-[220px] sm:w-[240px] lg:w-[268px]"
            />
          </Link>

          <nav className="hidden items-center justify-center gap-4 text-sm font-medium text-ink/75 lg:flex xl:gap-6">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="transition-colors duration-300 hover:text-accent"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            <Link href="#contact" className="primary-button">
              Đăng ký tư vấn
            </Link>
          </div>

          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-ink/10 bg-white text-ink lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Đóng menu" : "Mở menu"}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        <AnimatePresence initial={false}>
          {open ? (
            <motion.div
              id="mobile-nav"
              initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden lg:hidden"
            >
              <div className="mt-2 rounded-[24px] border border-ink/10 bg-white/95 p-3 shadow-soft">
                <div className="flex flex-col gap-2">
                  {navItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="rounded-2xl px-4 py-3 text-sm font-medium text-ink/80 transition hover:bg-ink/[0.04] hover:text-accent"
                      onClick={() => setOpen(false)}
                    >
                      {item.label}
                    </Link>
                  ))}
                  <Link
                    href="#contact"
                    className="primary-button mt-2"
                    onClick={() => setOpen(false)}
                  >
                    Đăng ký tư vấn
                  </Link>
                </div>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>
    </header>
  );
}
