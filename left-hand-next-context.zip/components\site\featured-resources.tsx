import Link from "next/link";
import { MotionReveal } from "@/components/site/motion-reveal";
import { SectionHeading } from "@/components/site/section-heading";
import { resources } from "@/data/site";

export function FeaturedResources() {
  return (
    <section id="resources" className="container-shell pt-5">
      <div className="section-shell px-5 py-8 sm:px-8 sm:py-10 lg:px-10">
        <div className="mb-7 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <MotionReveal className="w-full">
            <SectionHeading
              title="Tài liệu / khóa học nổi bật"
              className="mb-0 md:mx-0 md:text-left"
              align="left"
            />
          </MotionReveal>

          <MotionReveal delay={0.06}>
            <Link href="#contact" className="secondary-button">
              Cần tư vấn
            </Link>
          </MotionReveal>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
          {resources.map((item, index) => (
            <MotionReveal key={item.title} delay={0.04 * index}>
              <article className="surface-card hover-lift group flex h-full flex-col overflow-hidden p-3">
                <div
                  className={`relative overflow-hidden rounded-[22px] bg-gradient-to-br ${item.theme} p-5 text-center text-ink`}
                >
                  <span className="absolute left-3 top-3 rounded-full bg-accent px-3 py-1 text-[10px] font-semibold tracking-[0.14em] text-white">
                    {item.type}
                  </span>
                  <div className="flex min-h-[180px] items-center justify-center overflow-hidden rounded-[18px] border border-white/60 bg-white/55 px-4 py-6 backdrop-blur">
                    <p className="whitespace-pre-line text-2xl font-bold leading-[1.06] transition duration-500 group-hover:scale-[1.04]">
                      {item.coverTitle}
                    </p>
                  </div>
                </div>

                <div className="flex flex-1 flex-col px-2 pb-2 pt-5">
                  <h3 className="min-h-[3.25rem] text-lg font-semibold leading-7">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-sm leading-7 text-ink/72">
                    {item.summary}
                  </p>

                  <ul className="mt-4 space-y-2 text-sm leading-6 text-ink/76">
                    {item.points.map((point) => (
                      <li key={point} className="flex gap-2">
                        <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-accent" />
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="rounded-full bg-ink/[0.05] px-3 py-1 text-xs font-medium text-ink/75">
                      {item.price}
                    </span>
                    <span className="rounded-full bg-ink/[0.05] px-3 py-1 text-xs font-medium text-ink/75">
                      {item.term}
                    </span>
                  </div>

                  <button
                    type="button"
                    className="secondary-button mt-5 w-full"
                  >
                    {item.action}
                  </button>
                </div>
              </article>
            </MotionReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
