"use client";

import Image from "next/image";
import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { BookOpen, MessageCircleQuestion, UsersRound } from "lucide-react";
import { MotionReveal } from "@/components/site/motion-reveal";

const trustItems = [
  {
    icon: BookOpen,
    label: "Tài liệu theo môn, dễ lọc"
  },
  {
    icon: UsersRound,
    label: "Peer tutor và lớp ôn linh hoạt"
  },
  {
    icon: MessageCircleQuestion,
    label: "Hỏi bài nhanh khi cần"
  }
];

export function Hero() {
  const shouldReduceMotion = useReducedMotion();

  return (
    <section id="home" className="container-shell pt-4">
      <div className="section-shell relative overflow-hidden px-5 py-8 sm:px-8 sm:py-10 lg:px-10 lg:py-12">
        <div className="pointer-events-none absolute inset-y-0 right-0 hidden w-[42%] bg-[radial-gradient(circle_at_top,rgba(31,111,255,0.18),transparent_48%),radial-gradient(circle_at_bottom,rgba(255,191,71,0.18),transparent_36%)] lg:block" />

        <div className="relative grid items-center gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <MotionReveal>
            <div>
              <span className="eyebrow">Dành riêng cho sinh viên UFM</span>
              <h1 className="mt-5 max-w-2xl text-balance text-4xl font-bold leading-[0.97] text-ink sm:text-5xl lg:text-[4.15rem]">
                Đồng hành cùng <span className="text-accent">sinh viên UFM</span>{" "}
                trong học tập và ôn thi
              </h1>
              <p className="mt-5 max-w-xl text-base leading-8 text-ink/72 sm:text-lg">
                Tài liệu ôn thi, peer tutor, hỏi bài 24/7 và video bài giảng được
                gom lại để sinh viên UFM dễ tìm đúng thứ mình cần trước mỗi kỳ
                học, kỳ thi.
              </p>

              <div className="mt-5 flex flex-wrap gap-3 text-sm font-medium text-ink/75">
                <span className="rounded-full border border-ink/10 bg-white/80 px-4 py-2">
                  Ôn thi đi thoi
                </span>
                <span className="rounded-full border border-ink/10 bg-white/80 px-4 py-2">
                  Học tới gần điểm tối đa
                </span>
              </div>

              <div className="mt-7 flex flex-wrap gap-3">
                <Link href="#resources" className="primary-button">
                  Xem tài liệu
                </Link>
                <Link href="#contact" className="secondary-button">
                  Nhận tư vấn
                </Link>
              </div>

              <div className="mt-7 grid gap-3 sm:grid-cols-3">
                {trustItems.map((item) => (
                  <div
                    key={item.label}
                    className="rounded-[22px] border border-white/70 bg-white/85 px-4 py-4 shadow-[0_10px_22px_rgba(19,37,79,0.06)]"
                  >
                    <item.icon className="mb-3 h-5 w-5 text-accent" />
                    <p className="text-sm font-medium leading-6 text-ink/80">
                      {item.label}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </MotionReveal>

          <MotionReveal delay={0.08} className="relative">
            <motion.div
              animate={
                shouldReduceMotion
                  ? {}
                  : {
                      y: [0, -8, 0]
                    }
              }
              transition={
                shouldReduceMotion
                  ? undefined
                  : {
                      duration: 5.8,
                      ease: "easeInOut",
                      repeat: Number.POSITIVE_INFINITY
                    }
              }
              className="relative ml-auto flex w-full max-w-[900px] justify-end"
            >
              <div className="absolute left-[8%] top-[8%] h-28 w-28 rounded-full bg-accent/12 blur-3xl sm:h-36 sm:w-36" />
              <div className="absolute bottom-[10%] right-[8%] h-24 w-24 rounded-full bg-warm/20 blur-3xl sm:h-32 sm:w-32" />

              <Image
                src="/assets/branding/hero-left-hand-study-plan.png"
                alt="LEFT HAND study plan hero"
                width={1800}
                height={1400}
                priority
                className="relative z-10 h-auto w-full max-w-[860px] object-contain drop-shadow-[0_28px_50px_rgba(19,37,79,0.18)]"
                sizes="(max-width: 1024px) 100vw, 60vw"
              />
            </motion.div>
          </MotionReveal>
        </div>
      </div>
    </section>
  );
}
