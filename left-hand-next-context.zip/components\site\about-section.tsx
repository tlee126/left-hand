import { MotionReveal } from "@/components/site/motion-reveal";
import { SectionHeading } from "@/components/site/section-heading";
import { featureIcons } from "@/components/site/icon-map";
import { aboutItems } from "@/data/site";

export function AboutSection() {
  return (
    <section id="about" className="container-shell pt-5">
      <div className="section-shell px-5 py-8 sm:px-8 sm:py-10 lg:px-10">
        <MotionReveal>
          <SectionHeading
            title="LEFT HAND là gì?"
            description="LEFT HAND là nơi biến kiến thức đại học khô khan thành nội dung dễ tiếp cận, dễ ghi nhớ và dễ áp dụng cho sinh viên UFM."
          />
        </MotionReveal>

        <div className="grid gap-4 lg:grid-cols-3">
          {aboutItems.map((item, index) => {
            const Icon = featureIcons[item.icon];

            return (
              <MotionReveal key={item.title} delay={0.05 * index}>
                <article className="surface-card hover-lift flex h-full flex-col gap-4 p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-accent/10 text-accent">
                    <Icon className="h-6 w-6" />
                  </div>
                  <span className="eyebrow w-fit">{item.label}</span>
                  <h3 className="text-xl font-semibold leading-8">{item.title}</h3>
                  <p className="text-[15px] leading-7 text-ink/72">{item.body}</p>
                </article>
              </MotionReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
