import { MotionReveal } from "@/components/site/motion-reveal";
import { SectionHeading } from "@/components/site/section-heading";
import { impactStats } from "@/data/site";

export function ImpactStats() {
  return (
    <section id="impact" className="container-shell pt-5">
      <div className="section-shell px-5 py-8 sm:px-8 sm:py-10 lg:px-10">
        <MotionReveal>
          <SectionHeading
            title="Chúng mình đã đồng hành cùng sinh viên UFM như thế nào?"
            description="Những con số này không phải placeholder. Đây là hoạt động thật mà LEFT HAND đã duy trì qua từng học kỳ."
          />
        </MotionReveal>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {impactStats.map((item, index) => (
            <MotionReveal key={item.title} delay={0.05 * index}>
              <article className="surface-card hover-lift relative h-full overflow-hidden p-6">
                <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-accent via-sky-400 to-warm" />
                <span className="eyebrow mb-4 w-fit">{item.tag}</span>
                <strong className="block text-4xl font-bold tracking-tight text-accent">
                  {item.value}
                </strong>
                <p className="mt-2 text-base font-semibold leading-7 text-ink">
                  {item.title}
                </p>
                <p className="mt-3 text-sm leading-7 text-ink/70">{item.detail}</p>
              </article>
            </MotionReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
