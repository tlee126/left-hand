export type FeatureIconKey =
  | "book"
  | "users"
  | "question"
  | "play"
  | "search"
  | "pen"
  | "send"
  | "check"
  | "message";

export type SocialIconKey = "facebook" | "youtube" | "messenger";

export const navItems = [
  { label: "LEFT HAND là gì", href: "#about" },
  { label: "Dịch vụ", href: "#services" },
  { label: "Tài liệu", href: "#resources" },
  { label: "Tư vấn", href: "#contact" },
  { label: "Cộng đồng", href: "#ecosystem" }
];

export const aboutItems = [
  {
    title: "Tài liệu được chuẩn hóa theo môn",
    body: "Tài liệu ôn thi được tổng hợp theo học phần, có đề cương, bài tập mẫu và phần cần chú ý trước kỳ thi.",
    label: "Tài liệu",
    icon: "book" as FeatureIconKey
  },
  {
    title: "Có người gợi ý đúng thứ cần",
    body: "Khi chưa biết bắt đầu từ đâu, team sẽ giúp lọc ra tài liệu, tutor hoặc lớp ôn phù hợp với từng môn.",
    label: "Định hướng",
    icon: "search" as FeatureIconKey
  },
  {
    title: "Hỗ trợ sát nhu cầu sinh viên",
    body: "Không chỉ bán tài liệu, LEFT HAND ưu tiên hỗ trợ đúng lúc, đúng môn và đúng phần đang làm bạn kẹt.",
    label: "Hỗ trợ",
    icon: "message" as FeatureIconKey
  }
];

export const impactStats = [
  {
    value: "300+",
    title: "học viên được đồng hành",
    detail: "LEFT HAND đã hỗ trợ một cộng đồng đủ lớn để nhìn thấy nhu cầu học thật, không còn là thử nghiệm nhỏ.",
    tag: "Mỗi học kỳ"
  },
  {
    value: "10+",
    title: "lớp học được tổ chức",
    detail: "Lớp ôn được triển khai đều tay để bám kịp lịch học, lịch thi và các môn có nhu cầu cao.",
    tag: "Mỗi học kỳ"
  },
  {
    value: "65+",
    title: "học viên tương tác trực tiếp",
    detail: "Team vẫn giữ được nhịp hỏi đáp tốt trong các buổi online kéo dài, không biến lớp học thành video một chiều.",
    tag: "Buổi online 2 giờ"
  },
  {
    value: "03",
    title: "cộng đồng đang vận hành",
    detail: "Ba cộng đồng học thuật giúp LEFT HAND duy trì kết nối, cập nhật nhu cầu và hỗ trợ theo nhóm môn rõ ràng.",
    tag: "Cộng đồng học thuật"
  }
];

export const services = [
  {
    title: "Tài liệu ôn thi",
    body: "Tài liệu được tổng hợp theo môn, có đề cương, bài tập, ghi chú trọng tâm và phần cần chú ý trước kỳ thi.",
    label: "Tài liệu",
    icon: "book" as FeatureIconKey
  },
  {
    title: "Peer Tutor",
    body: "Học cùng tutor là sinh viên hoặc cựu sinh viên đã qua môn, phù hợp khi cần người giải thích lại phần chưa hiểu.",
    label: "Peer Tutor",
    icon: "users" as FeatureIconKey
  },
  {
    title: "Hỏi bài 24/7",
    body: "Gửi câu hỏi hoặc bài tập, team hỗ trợ định hướng cách làm và nhắc lại phần kiến thức liên quan.",
    label: "Hỗ trợ nhanh",
    icon: "question" as FeatureIconKey
  },
  {
    title: "Video bài giảng / lớp ôn",
    body: "Video ngắn và lớp ôn giúp bạn học lại nhanh các phần dễ gặp trong kiểm tra mà không phải tự ghép quá nhiều nguồn.",
    label: "Video & lớp ôn",
    icon: "play" as FeatureIconKey
  }
];

export const resources = [
  {
    title: "Kế toán tài chính 1",
    summary: "Đề cương, bài tập mẫu, ghi chú trọng tâm và phần cần chú ý trước kỳ thi.",
    points: ["Đề cương + bài tập mẫu", "Ghi chú trọng tâm", "Phù hợp ôn giữa kỳ / cuối kỳ"],
    price: "29.000đ",
    term: "Midterm + Final",
    type: "TÀI LIỆU",
    coverTitle: "KẾ TOÁN\nTÀI CHÍNH 1",
    theme: "from-blue-50 via-white to-sky-100",
    action: "Xem nội dung"
  },
  {
    title: "Kinh tế vi mô",
    summary: "Học cùng tutor đã qua môn, giải thích lại phần chưa hiểu và gợi ý cách học theo từng chương.",
    points: ["1 buổi 60 phút", "Giải lại ví dụ / bài tập", "Phù hợp khi bị mất gốc từ đầu kỳ"],
    price: "Liên hệ",
    term: "Midterm",
    type: "PEER TUTOR",
    coverTitle: "KINH TẾ\nVI MÔ",
    theme: "from-indigo-50 via-white to-violet-100",
    action: "Cần tư vấn"
  },
  {
    title: "Xác suất thống kê",
    summary: "Lớp ôn tập trung vào dạng bài hay ra, có slide, bài tập và phần giải đáp cuối buổi.",
    points: ["4 buổi ôn tập", "Slide + bài tập luyện", "Phù hợp ôn cuối kỳ"],
    price: "99.000đ",
    term: "Final",
    type: "LỚP ÔN",
    coverTitle: "XÁC SUẤT\nTHỐNG KÊ",
    theme: "from-amber-50 via-white to-orange-100",
    action: "Đăng ký lớp"
  },
  {
    title: "Marketing căn bản",
    summary: "Video ngắn và lớp ghi hình giúp ôn lại chương dễ quên, xem lại theo nhịp riêng.",
    points: ["Video ngắn theo chương", "Tóm tắt nội dung chính", "Phù hợp giữa kỳ / cuối kỳ"],
    price: "Liên hệ",
    term: "Midterm + Final",
    type: "VIDEO BÀI GIẢNG",
    coverTitle: "MARKETING\nCĂN BẢN",
    theme: "from-emerald-50 via-white to-lime-100",
    action: "Xem nội dung"
  },
  {
    title: "Quản trị học",
    summary: "Bộ tài liệu gọn, dễ lật lại phần lý thuyết, câu hỏi ôn và checklist trước giờ thi.",
    points: ["Giáo trình tóm lược", "Bộ câu hỏi ôn thi", "Phù hợp ôn giữa kỳ"],
    price: "20.000đ",
    term: "Midterm",
    type: "TÀI LIỆU",
    coverTitle: "QUẢN TRỊ\nHỌC",
    theme: "from-teal-50 via-white to-cyan-100",
    action: "Xem nội dung"
  }
];

export const processSteps = [
  {
    step: "1",
    title: "Chọn môn học hoặc phần đang kẹt",
    body: "Ghi rõ học phần để team biết bạn đang cần ôn giữa kỳ, cuối kỳ hay chỉ cần gỡ một đoạn kiến thức.",
    icon: "search" as FeatureIconKey
  },
  {
    step: "2",
    title: "Ghi nhu cầu thật rõ",
    body: "Chọn tài liệu, peer tutor, hỏi bài 24/7 hoặc video bài giảng / lớp ôn để nhận đúng gợi ý.",
    icon: "pen" as FeatureIconKey
  },
  {
    step: "3",
    title: "Team lọc và sắp xếp",
    body: "Chúng mình xem nhu cầu, đối chiếu với môn học và đề xuất tài nguyên phù hợp nhất trong thời điểm đó.",
    icon: "check" as FeatureIconKey
  },
  {
    step: "4",
    title: "Nhận tài liệu hoặc lịch lớp",
    body: "Bạn được gửi đúng tài liệu, đúng lịch lớp hoặc được ghép vào tutor phù hợp để theo kịp tiến độ.",
    icon: "send" as FeatureIconKey
  }
];

export const testimonials = [
  {
    quote: "Mình cần ôn gấp trước thi, tài liệu được gom sẵn nên đỡ mất thời gian tìm lại trong drive.",
    author: "Sinh viên Kế toán",
    detail: "Đã dùng tài liệu ôn giữa kỳ"
  },
  {
    quote: "Tutor giải thích dễ hiểu, nhất là mấy phần mình bị mất gốc từ đầu kỳ.",
    author: "Sinh viên Marketing",
    detail: "Đã học kèm 1:1"
  }
];

export const socialLinks = [
  {
    name: "Facebook",
    description: "Cập nhật tài liệu mới, lịch lớp ôn và các thông báo hỗ trợ theo từng học kỳ.",
    href: "#",
    cta: "Theo dõi ngay",
    icon: "facebook" as SocialIconKey
  },
  {
    name: "YouTube",
    description: "Video ngắn, phần ôn tắt và các đoạn giải thích lại kiến thức nền dễ quên.",
    href: "#",
    cta: "Xem ngay",
    icon: "youtube" as SocialIconKey
  },
  {
    name: "Messenger",
    description: "Nơi sinh viên hỏi nhanh, nhận hỗ trợ và được gợi ý tài liệu hoặc lớp phù hợp.",
    href: "#",
    cta: "Nhắn tin ngay",
    icon: "messenger" as SocialIconKey
  }
];

export const faculties = [
  "Kế toán - Kiểm toán",
  "Kinh tế",
  "Marketing",
  "Tài chính - Ngân hàng",
  "Hệ thống thông tin quản lý",
  "Khác"
];

export const interests = [
  "Kế toán tài chính 1",
  "Kinh tế vi mô",
  "Xác suất thống kê",
  "Marketing căn bản",
  "Quản trị học",
  "Chưa biết, cần tư vấn"
];

export const needs = [
  "Tài liệu ôn thi",
  "Peer Tutor",
  "Hỏi bài 24/7",
  "Video bài giảng / lớp ôn",
  "Chưa biết, cần tư vấn"
];
