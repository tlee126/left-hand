import { MotionReveal } from "@/components/site/motion-reveal";
import { SectionHeading } from "@/components/site/section-heading";
import { testimonials } from "@/data/site";

export function TestimonialsSection() {
  return (
    <section id="trust" className="container-shell pt-5">
      <div className="section-shell px-5 py-8 sm:px-8 sm:py-10 lg:px-10">
        <MotionReveal>
          <SectionHeading
            title="Sinh viên nói gì về LEFT HAND"
            description="Những phản hồi ẩn danh dưới đây được viết lại ngắn gọn để phản ánh cách sinh viên đang dùng LEFT HAND trong mùa ôn thi."
          />
        </MotionReveal>

        <div className="grid gap-4 lg:grid-cols-2">
          {testimonials.map((item, index) => (
            <MotionReveal key={item.author} delay={0.05 * index}>
              <article className="surface-card hover-lift h-full p-6 sm:p-7">
                <span className="text-4xl font-bold leading-none text-accent/30">
                  “
                </span>
                <p className="mt-3 text-base leading-8 text-ink/78">{item.quote}</p>
                <div className="mt-6 flex items-center gap-3">
                  <div className="h-11 w-11 rounded-full bg-gradient-to-br from-accent/20 to-warm/40" />
                  <div>
                    <strong className="block text-sm font-semibold text-ink">
                      {item.author}
                    </strong>
                    <span className="text-sm text-ink/65">{item.detail}</span>
                  </div>
                </div>
              </article>
            </MotionReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
